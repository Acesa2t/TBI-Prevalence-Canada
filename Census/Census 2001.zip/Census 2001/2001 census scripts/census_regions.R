# Prior script census_country1
# Now can I add the WHO regions?

library(readxl)
library(writexl)
library(janitor)
library(tidyverse)

# Read in Data

regions <- read_xlsx("jme_regional_classifications.xlsx")
regions <- regions%>%
  select("Iso3 code","WHO Region2")
regions
colnames(regions) <- c("iso3", "WHO_regions")
View(regions)

# I'm going to remove any regions in this dataset because they don't have iso3 codes
census_iso3 <- readRDS("census_iso3_2001.rds")
View(census_iso3)
census_iso3 <- census_iso3%>%
  filter(!is.na(ISO3))%>%
  filter(!COO%in%c("Caribbean and Bermuda"))

#,"Czech and Slovak Federal Republic, Former"

View(census_iso3)

# Join the datasets
unique(regions$WHO_regions)
colnames(regions) <- c("ISO3", "WHO_R")
str(regions)
str(census_iso3)

census_regions <- merge(regions, census_iso3, by = "ISO3")
census_regions <- census_regions%>%select(-X1)
View(census_regions)
# Let's me know which regions are not classified. This will later be addressed in census_NC
#a <- census_regions%>%
  filter(WHO_regions == "Not Classified")
#View(unique(a%>%select(COO,ISO3)))

#census_test <- dplyr::distinct(census_regions)
#View(census_test)
View(census_regions%>%
       summarise(tot_pop = sum(as.numeric(NUMP))))

unique(census_regions$COO)

saveRDS(census_regions, 
        file = "/Users/ajordan/OneDrive - McGill University/LTBI-Aust-CEA-master/Census/Census 2001/census_who_2001.rds")

# Next script census_afr.R