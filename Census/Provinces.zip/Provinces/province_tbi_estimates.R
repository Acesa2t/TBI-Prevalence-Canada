# Document used to add Age at Arrival (AARP) column, add WHO regions, eventually incidence bands will be added as well. Unnecessary columns also removed

rm(list = ls(all.names = TRUE))
gc()

library(spatstat)
library(tidyverse)

# Alberta total population: 839439.5, median LTBP: 202993, UR 2.5%: 172818, UR %95: 231094, overall TBI-prev: 24% (21-28)

# BC population: 1252290, median LTBP: 299373, UR 2.5%: 243768, UR 95%: 368858, overall TBI prev: 24 (20-29)

# Ontario

# Quebec

# Other provinces

# Read file in
tbi <- readRDS("/Users/ajordan/Library/CloudStorage/OneDrive-McGillUniversity/LTBI-Aust-CEA-master/Data/census_bc_v1.rds")
#View(tbi)
View(tbi%>%summarize(sum(NUMP)))
#write.csv(tbi,"/Users/ajordan/OneDrive - McGill University/LTBI-Aust-CEA-master/Data/Outputs/tbi_est.csv", row.names = FALSE)
tbi <- tbi%>%filter(NUMP > 0 | ISO3 != "CAN")%>%filter(YARP >= YOBP)

#View(list(tbi$LTBP))

ltbp_set <- do.call(rbind.data.frame, tbi$LTBP)
colnames(ltbp_set) <- c(1:200)
View(ltbp_set)

ltbp_summary <- data.frame(t(ltbp_set%>%summarise(across(everything(), sum))))
colnames(ltbp_summary) <- c("LTBP_tot")
class(ltbp_summary)
median(ltbp_summary$LTBP_tot)
quantile(ltbp_summary$LTBP_tot, 0.025)
quantile(ltbp_summary$LTBP_tot, 0.95)


# Age groups

tbi_age_groups <- tbi%>%
  mutate(AGE_BANDS = ifelse(
    AGEP < 15, "0-14", ifelse(
      AGEP >= 15 & AGEP < 35, "15-34", ifelse(
        AGEP >= 35 & AGEP < 55, "35-54",ifelse(
          AGEP >= 55 & AGEP < 75, "55-74",ifelse(
            AGEP >= 75 & AGEP <= 200, "75+", "No value"))))),
    AARP = YARP-YOBP)%>%
  mutate(AARP_BANDS = ifelse(
    AARP < 15, "AARP 0-14", ifelse(
      AARP >= 15 & AARP < 35, "AARP 15-34", ifelse(
        AARP >= 35 & AARP < 55, "AARP 35-54",ifelse(
          AARP >= 55 & AARP <= 74, "AARP 55-74", ifelse(
            AARP >= 75 & AARP <= 200, "AARP 75+", "No value"))))))
  
